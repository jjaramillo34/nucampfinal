CKEDITOR.plugins.setLang( 'html5audio', 'pl', {
    button: 'Wstaw HTML5 audio',
    title: 'HTML5 audio',
    infoLabel: 'Informacje o pliku',
    urlMissing: 'Nie znaleziono URL do pliku audio.',
    audioProperties: 'Właściwości ',
    upload: 'Wrzuć plik',
    btnUpload: 'Wyślij na serwer',
    advanced: 'Zaawansowane',
    autoplay: 'Autoodtwarzanie?',
    allowdownload: 'zezwolić na pobieranie?',
    advisorytitle: 'Advisory title',
    yes: 'Tak',
    no: 'Nie'
} );
